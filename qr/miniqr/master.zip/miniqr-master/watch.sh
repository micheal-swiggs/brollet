#! /bin/bash
coffee --watch --compile --output js/lib/ js/src/